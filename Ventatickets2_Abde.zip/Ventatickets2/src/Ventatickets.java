import java.util.List;
import java.util.ArrayList;

public class Ventatickets {
    static List<Eventos> eventosActivos = new ArrayList<Eventos>();
    static List<Integer> Compradores = new ArrayList<>();
    static List<Integer> Asistencia = new ArrayList<>();
    static List<Object> cerrojosEventos = new ArrayList<>(); // Lista de objetos para cerrojos
    static int entradasQuedan;
    static int ultimasEntradasReportadas = -1;
    static Object cerrojoReporte = new Object(); // Objeto para cerrojo de reporte

    public static void main(String[] args) {
        crearEventos();
        System.out.println("LLEGAN NUEVOS COMPRADORES");
        List<Thread> threads = new ArrayList<>();
        crearCompradores(threads);

        for (Thread t : threads) {
            try {
                t.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println("Todas las compras han sido procesadas");
        mostrarResumenFinal();
    }

    static void crearEventos() {
        int aleatorio = (int) (Math.random() * 3 + 3);
        for (int i = 0; i < aleatorio; i++) {
            Eventos eventoAnadir = new Eventos();
            eventoAnadir.crearEvento();
            eventosActivos.add(eventoAnadir);
            cerrojosEventos.add(new Object()); // Creamos un objeto para cerrojo por cada evento
        }
    }

    static void crearCompradores(List<Thread> threads) {
        int aleatorio = (int) (Math.random() * 50 + 20);
        for (int i = 0; i < aleatorio; i++) {
            int cantidadTickets = (int) (Math.random() * 10 + 1);
            int eventoSeleccionado = (int) (Math.random() * eventosActivos.size());
            Compradores.add(cantidadTickets);
            Asistencia.add(eventoSeleccionado);

            System.out.println(i + " NUEVO COMPRADOR: Quiere " + cantidadTickets + " tickets para el evento: " +
                    eventosActivos.get(eventoSeleccionado).eventoNombre);

            Thread t = new Thread(new Comprador(i, cantidadTickets, eventoSeleccionado));
            threads.add(t);
            t.start();
        }
    }

    static void mostrarResumenFinal() {
        System.out.println("\n=== RESUMEN FINAL DE EVENTOS ===");
        for (Eventos evento : eventosActivos) {
            System.out.println("Evento: " + evento.eventoNombre +
                    " - Entradas restantes: " + evento.entradas);
        }
        System.out.println("Total de entradas restantes: " + entradasQuedan);
    }

    static class Comprador implements Runnable {
        int id;
        int cantidadTickets;
        int eventoSeleccionado;

        Comprador(int id, int cantidadTickets, int eventoSeleccionado) {
            this.id = id;
            this.cantidadTickets = cantidadTickets;
            this.eventoSeleccionado = eventoSeleccionado;
        }

        @Override
        public void run() {
            // Obtenemos el objeto cerrojo correspondiente al evento
            Object cerrojoEvento = cerrojosEventos.get(eventoSeleccionado);

            synchronized(cerrojoEvento) {
                // Verificamos disponibilidad y realizamos la venta
                Eventos eventoActual = eventosActivos.get(eventoSeleccionado);
                if (cantidadTickets <= eventoActual.entradas) {
                    System.out.println("Comprador " + id + ": VAMOS A VENDER " + cantidadTickets + " ENTRADAS!!");
                    eventoActual.entradas -= cantidadTickets;

                    // Actualizamos el contador total de entradas
                    synchronized(cerrojoReporte) {
                        actualizarEntradasRestantes();
                    }
                } else {
                    if (eventoActual.entradas > 0) {
                        System.out.println("Comprador " + id + ": Solo quedan " +
                                eventoActual.entradas +
                                " entradas. NO SE PUEDE REALIZAR LA VENTA COMPLETA!!");
                    } else {
                        System.out.println("Comprador " + id + ": SOLD OUT");
                    }
                }
            }
        }
    }

    static void actualizarEntradasRestantes() {
        entradasQuedan = 0;
        for (Eventos evento : eventosActivos) {
            if (evento.entradas > 0) {
                entradasQuedan += evento.entradas;
            }
        }

        if (entradasQuedan != ultimasEntradasReportadas) {
            if (entradasQuedan > 0) {
                System.out.println("Quedan aún " + entradasQuedan + " entradas por vender");
            } else {
                System.out.println("YA NO QUEDAN ENTRADAS");
            }
            ultimasEntradasReportadas = entradasQuedan;
        }
    }
}