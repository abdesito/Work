//Prog_P6_Abdellah_Sahad.
package Practic8; //Declaración del paquete al que pertenece.

// Importación de las clases.
import java.io.FileWriter;
import java.time.LocalDate;
import java.io.BufferedWriter;

public class Venta  {
// Declaración de los atributos.
	private LocalDate fecha;
    private double precioSinIVA;
    private String articulo;
    private int unidades;
    private double iva;
    private Cliente cliente;
    private RepresentanteDeVentas representanteDeVentas;

    //Metodos get y set.
    public Venta(LocalDate localDate, double precioSinIVA, String articulo, int unidades, double iva, Cliente cliente, RepresentanteDeVentas representanteDeVentas) {
        setFecha(localDate);
        setPrecioSinIVA(precioSinIVA);
        setArticulo(articulo);
        setUnidades(unidades);
        setIVA(iva);
        setCliente(cliente);
        setRepresentanteDeVentas(representanteDeVentas);
        
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate localDate) {
     
        this.fecha = localDate;
    }

    public double getPrecioSinIVA() {
        return precioSinIVA;
    }

    public void setPrecioSinIVA(double precioSinIVA) {

        this.precioSinIVA = precioSinIVA;
    }

    public String getArticulo() {
        return articulo;
    }

    public void setArticulo(String articulo) {
        this.articulo = articulo;
    }

    public int getUnidades() {
        return unidades;
    }

    public void setUnidades(int unidades) {
        
        this.unidades = unidades;
    }

    public double getIVA() {
        return iva;
    }

    public void setIVA(double iva) {
   
        this.iva = iva;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public RepresentanteDeVentas getRepresentanteDeVentas() {
        return representanteDeVentas;
    }

    public void setRepresentanteDeVentas(RepresentanteDeVentas representanteDeVentas) {
        this.representanteDeVentas = representanteDeVentas;
    }

    public double getPrecioConIVA() {
        return precioSinIVA + (precioSinIVA * iva / 100);
    }
    public double calcularComisionRepresentante() {  // Método para calcular la comisión del representante de ventas.
        double precioConIVA = precioSinIVA * (1 + iva); // Retorna la comisión del representante de ventas.
        return precioConIVA * representanteDeVentas.getPorcentajeDeComision();}
    
    public void sacarDatos(String outFile) {
        try {
            BufferedWriter fw = new BufferedWriter(new FileWriter(outFile));  // Creación de un BufferedWriter para escribir en el archivo especificado
            fw.write("Los datos de la venta son:");
            fw.write("Nombre del cliente = " + this.getCliente().getNombreCompleto());
            fw.write("El DNI del cliente es: = " + this.getCliente().getDNI());
            fw.write("El correo electrónico del cliente es: = " + this.getCliente().getCorreoElectronico());
            fw.write("El nombre del representante de ventas es: = " + this.getRepresentanteDeVentas().getNombreCompletoRepresentanteDeVentas());
            fw.write("El precio sin IVA es: = " + this.getPrecioSinIVA());
            fw.write("El precio con IVA es:= " + this.getPrecioConIVA());

           
            fw.close();
        } catch (Exception e) {
            
            e.printStackTrace();
        }
    }

	
	}

	
	

