//Prog_P6_Abdellah_Sahad.
package Practic8;
// Importación de las clases
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.Date;

public class Persona {
// Declaración de atributos.
	  private String nombre;
	    private String apellido;
	    private String dni;
	    private String correoElectronico;
	    private String fechaNacimiento;
	    private int edad;
	// Declaración de los métodos.
	    public Persona(String nombre, String apellido, String dni, String correoElectronico, String fechaNacimiento) {
	        setNombre(nombre);
	        setApellido(apellido);
	        verificarDNI(dni);
	        verificarCorreo(correoElectronico);
	        setFechaNacimiento(fechaNacimiento);
	    }
	
	    public String getNombre() {
	        return this.nombre;
	    }
	
	    public void setNombre(String nombre) {
	        this.nombre = nombre;
	    }
	
	    public String getApellido() {
	        return apellido;
	    }
	
	    public void setApellido(String apellido) {
	        this.apellido = apellido;
	    }
	
	    public String getDNI() {
	        return this.dni;
	    }
	
	    public void setDNI(String dni) { // Metodo para asignar el DNI.
	        verificarDNI(dni); // Verificador del DNI.
	        this.dni = dni;
	    }
	
	    public String getCorreoElectronico() { // Metodo para obtener el correo electronico.
	        return this.correoElectronico;
	    }
	
	    public void setCorreoElectronico(String correoElectronico) {
	        verificarCorreo(correoElectronico); // Verificador correo electronico.
	        this.correoElectronico = correoElectronico;
	    }
	
	    public String getFechaNacimiento() {
	        return this.fechaNacimiento;
	    }
	
	    public void setFechaNacimiento(String fechaNacimiento) { //Metodo para calcular la edad a partir de la fecha de nacimiento.
	        try {
	            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd"); //Metodo para asignar la fecha de nacimiento.
	            Date fecha = dateFormat.parse(fechaNacimiento);
	            this.fechaNacimiento = fechaNacimiento;
	            calcularEdad(fecha);
	        } catch (ParseException e) {
	            throw new IllegalArgumentException("Formato de fecha incorrecto. Utilice el formato YYYY-MM-DD");
	        }
	    }
	
	    private void calcularEdad(Date fechaNacimiento) {
	        LocalDate nacimiento = fechaNacimiento.toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDate();
	        LocalDate hoy = LocalDate.now();
	        Period periodo = Period.between(nacimiento, hoy);
	        this.edad = periodo.getYears();
	    }
	
	    public int getEdad() { // Metodo para obtener la edad.
	        return this.edad;
	    }
	
	    public String getNombreCompleto() {
	        return this.nombre + " " + this.apellido;
	    }
	
	    private void verificarCorreo(String correo) {
	        if (!correo.contains("@") || !correo.endsWith(".com")) {
	            throw new IllegalArgumentException("Formato de correo electrónico incorrecto");
	        }
	        this.correoElectronico = correo;
	    }
	
	    private void verificarDNI(String dni) { // Metodo para verificar e formato del DNI, apoyado en chatgpt.
	      
	        if (dni.length() != 9) {
	            throw new IllegalArgumentException("Formato de DNI incorrecto");
	        }
	        this.dni = dni;
	    }
	}

