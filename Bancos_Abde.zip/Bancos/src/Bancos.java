import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Bancos {
    static class CuentaBancaria {
        private final int id;
        private BigDecimal saldo;

        public CuentaBancaria(int id, double saldoInicial) {
            this.id = id;
            this.saldo = BigDecimal.valueOf(saldoInicial).setScale(2, RoundingMode.HALF_EVEN);
        }

        public int getId() {
            return id;
        }

        public synchronized BigDecimal getSaldo() {
            return saldo;
        }

        public synchronized boolean depositar(double monto) {
            saldo = saldo.add(BigDecimal.valueOf(monto).setScale(2, RoundingMode.HALF_EVEN));
            return true;
        }

        public synchronized boolean retirar(double monto, boolean permitirNegativo) {
            BigDecimal montoBD = BigDecimal.valueOf(monto).setScale(2, RoundingMode.HALF_EVEN);
            if (saldo.compareTo(montoBD) >= 0 || permitirNegativo) {
                saldo = saldo.subtract(montoBD);
                return true;
            }
            return false;
        }
    }

    static boolean realizarTransferencia(CuentaBancaria origen, CuentaBancaria destino, double monto) {
        CuentaBancaria primera = origen.getId() < destino.getId() ? origen : destino;
        CuentaBancaria segunda = origen.getId() < destino.getId() ? destino : origen;

        synchronized (primera) {
            synchronized (segunda) {
                if (origen.retirar(monto, false)) {
                    destino.depositar(monto);
                    return true;
                }
            }
        }
        return false;
    }

    static boolean realizarPagoMonedero(CuentaBancaria cuenta, double monto) {
        synchronized (cuenta) {
            return cuenta.retirar(monto, false);
        }
    }

    public static void main(String[] args) {
        // Generar cuentas bancarias
        List<CuentaBancaria> cuentas = new ArrayList<>();
        Random random = new Random();
        for (int i = 0; i < 100; i++) {
            cuentas.add(new CuentaBancaria(i, 1000 + random.nextDouble() * 9000));
        }

        // Generar 500 operaciones
        for (int i = 0; i < 500; i++) {
            int tipoOperacion = random.nextInt(3); // 0: Transferencia, 1: Pago Monedero, 2: Depósito
            double monto = 50 + random.nextDouble() * 950; // Entre 50 y 1000 euros
            monto = Math.round(monto * 100.0) / 100.0; // Redondear a 2 decimales
            int cuenta1 = random.nextInt(100);
            int cuenta2 = random.nextInt(100);
            while (cuenta1 == cuenta2) {
                cuenta2 = random.nextInt(100);
            }

            switch (tipoOperacion) {
                case 0: // Transferencia
                    if (realizarTransferencia(cuentas.get(cuenta1), cuentas.get(cuenta2), monto)) {
                        System.out.println("[TRANSFERENCIA] De la cuenta " + cuenta1 + " a la cuenta " + cuenta2 + " por " + monto + "€.");
                        if (monto > 600) {
                            System.out.println("  > AVISO: Transferencia superior a 600€ detectada.");
                        }
                    } else {
                        System.out.println("[TRANSFERENCIA FALLIDA] De la cuenta " + cuenta1 + " a la cuenta " + cuenta2 + " por " + monto + "€.");
                    }
                    break;

                case 1: // Pago Monedero
                    if (realizarPagoMonedero(cuentas.get(cuenta1), monto)) {
                        System.out.println("[PAGO MONEDERO] De la cuenta " + cuenta1 + " por " + monto + "€.");
                    } else {
                        System.out.println("[PAGO MONEDERO FALLIDO] De la cuenta " + cuenta1 + " por " + monto + "€.");
                    }
                    break;

                case 2: // Depósito
                    synchronized (cuentas.get(cuenta1)) {
                        cuentas.get(cuenta1).depositar(monto);
                    }
                    System.out.println("[DEPÓSITO] En la cuenta " + cuenta1 + " por " + monto + "€.");
                    break;
            }
        }

        // Mostrar saldos finales
        System.out.println("\nSaldos finales:");
        for (CuentaBancaria cuenta : cuentas) {
            System.out.println("Cuenta " + cuenta.getId() + " - Saldo: " + cuenta.getSaldo() + "€");
        }
    }
}
