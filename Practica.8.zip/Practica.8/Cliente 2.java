//Prog_P6_Abdellah_Sahad.
package Practic8;


// Implementación de las clases necesarias.
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Cliente extends Persona {

	private String fechaDeAlta;
	
    public Cliente(String nombre, String apellido, String dni, String correoElectronico, String fechaNacimiento, String fechaDeAlta) {
        super(nombre, apellido, dni, correoElectronico, fechaNacimiento);
        setFechaDeAlta(fechaDeAlta);
    }
// metodo para obtene la fecha de alta.
    public String getFechaDeAlta() {
        return fechaDeAlta;
    }
 // Método para asignar la fecha de alta, apoyado en chatgpt.
    public void setFechaDeAlta(String fechaDeAlta) {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            dateFormat.parse(fechaDeAlta);
            this.fechaDeAlta = fechaDeAlta;
        } catch (ParseException e) {
            throw new IllegalArgumentException("Formato de fecha de alta incorrecto. Utilice el formato YYYY-MM-DD");
        }
    }
 // Método para calcular los días transcurridos desde la fecha de alta
    public int diasDesdeAlta() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date fechaAlta = dateFormat.parse(fechaDeAlta);
            Date hoy = new Date();
            long diferenciaEnMs = hoy.getTime() - fechaAlta.getTime();
            return (int) (diferenciaEnMs / (24 * 60 * 60 * 1000));
        } catch (ParseException e) {
            e.printStackTrace();
            return -1;  
        }
    }

 // Métodos heredados de la clase Persona

	public String getNombreCompletoRepresentanteDeVentas() {
		
		return getNombreCompletoRepresentanteDeVentas();
	}

	public String getPrecioSinIva() {
		
		return getPrecioSinIva();
	}

	public String getPrecioConIva() {
		
		return getPrecioConIva();
	}

	}

