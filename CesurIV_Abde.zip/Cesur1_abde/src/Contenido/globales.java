/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Contenido;

/**
 *
 * @author AbdellahSahadBenhaid
 */
public class globales {
    
    public static String driver = "com.mysql.cj.jdbc.Driver";
    public static String usuario = "";
    public static String password = "";
    public static String url = "jdbc:mysql://localhost:3306/pruebilla"; 
}
