package Practic8;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;


public class Negocio {

    
        private List<Venta> ventas;
    
        public Negocio(Venta[] ventas) {
            this.ventas = new ArrayList<>(Arrays.asList(ventas));
        }
    
        // Método para añadir una venta
        public void agregarVenta(Venta venta) {
            this.ventas.add(venta);
        }
    
        // Método para quitar una venta (pasarle un �ndice)
        public void quitarVenta(int indice) {
            if (indice >= 0 && indice < ventas.size()) {
                this.ventas.remove(indice);
            } else {
                throw new IndexOutOfBoundsException("�ndice fuera de rango");
            }
        }
        
        public Venta getVenta(int indice) {
            if (indice >= 0 && indice < ventas.size()) {
                return this.ventas.get(indice);
            } else {
                throw new IndexOutOfBoundsException("�ndice fuera de rango");
            }
        }

        public List<Venta> getVentas() {
            return this.ventas;
        }
        
    public  void sacarXML() {
     

        try {
            Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
            
            Element ventas = crearGrupoVentas(doc, new ArrayList<>(this.ventas));

            
            doc.appendChild(ventas);
            
            TransformerFactory transFact = TransformerFactory.newInstance();
            transFact.setAttribute("indent-number", 3);
            
            Transformer trans = transFact.newTransformer();
            
            trans.setOutputProperty(OutputKeys.INDENT, "yes");
            trans.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
            
            StringWriter sw = new StringWriter();
            
            StreamResult sr = new StreamResult(sw);
            
            DOMSource domSource = new DOMSource(doc);
            
            trans.transform(domSource, sr);
            
            PrintWriter wr = new PrintWriter(new FileWriter("negocio.xml"));
            
            wr.println(sw.toString());
            
            wr.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private static Element crearElementoVenta(Document doc, Venta venta) {
        Element ventaElement = doc.createElement("Venta");
        
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        
        // Datos de la venta
        Element datosVenta = doc.createElement("DatosVenta");
        ventaElement.appendChild(datosVenta);
        
        Element fecha = doc.createElement("Fecha");
        fecha.appendChild(doc.createTextNode(venta.getFecha().format(formatter)));
        datosVenta.appendChild(fecha);
        
        Element articulo = doc.createElement("Articulo");
        articulo.appendChild(doc.createTextNode(venta.getArticulo()));
        datosVenta.appendChild(articulo);
        
        Element precioConIVA = doc.createElement("PrecioConIVA");
        precioConIVA.appendChild(doc.createTextNode(String.valueOf(venta.getPrecioConIVA())));
        datosVenta.appendChild(precioConIVA);
        
        Element Unidades = doc.createElement("Unidades");
        Unidades.appendChild(doc.createTextNode(String.valueOf(venta.getUnidades())));
        datosVenta.appendChild(Unidades);
        
        // Datos del cliente
        Element datosCliente = doc.createElement("DatosCliente");
        ventaElement.appendChild(datosCliente);
        
        Element nombreCliente = doc.createElement("NombreCompleto");
        nombreCliente.appendChild(doc.createTextNode(venta.getCliente().getNombreCompleto()));
        datosCliente.appendChild(nombreCliente);
        
        Element correoCliente = doc.createElement("CorreoElectronico");
        correoCliente.appendChild(doc.createTextNode(venta.getCliente().getCorreoElectronico()));
        datosCliente.appendChild(correoCliente);
        
        
        
        Element fechaNacimientos = doc.createElement("FechaNacimiento");
        fechaNacimientos.appendChild(doc.createTextNode(String.valueOf(venta.getCliente().getFechaNacimiento())));
        datosCliente.appendChild(fechaNacimientos);
        
        
        Element fechaAlta = doc.createElement("FechaAlta");
        fechaAlta.appendChild(doc.createTextNode(String.valueOf(venta.getCliente().getFechaDeAlta())));
        datosCliente.appendChild(fechaAlta);
        
        Element dniCliente = doc.createElement("DNI");
        dniCliente.appendChild(doc.createTextNode(venta.getCliente().getDNI()));
        datosCliente.appendChild(dniCliente);
        
        // Datos del representante de ventas
        Element datosRepresentante = doc.createElement("DatosRepresentante");
        ventaElement.appendChild(datosRepresentante);
        
        Element nombreRepresentante = doc.createElement("NombreCompleto");
        nombreRepresentante.appendChild(doc.createTextNode(venta.getRepresentanteDeVentas().getNombreCompletoRepresentanteDeVentas()));
        datosRepresentante.appendChild(nombreRepresentante);
        
        Element dniRepresentante = doc.createElement("DNI");
        dniRepresentante.appendChild(doc.createTextNode(venta.getRepresentanteDeVentas().getDNI()));
        datosRepresentante.appendChild(dniRepresentante);
        
        Element comision = doc.createElement("Comision");
        comision.appendChild(doc.createTextNode(String.valueOf(venta.calcularComisionRepresentante())));
        datosRepresentante.appendChild(comision);
        
        Element fechaNacimiento = doc.createElement("FechaNacimiento");
        fechaNacimiento.appendChild(doc.createTextNode(String.valueOf(venta.getRepresentanteDeVentas().getFechaNacimiento())));
        datosRepresentante.appendChild(fechaNacimiento);
        
        Element correo = doc.createElement("correo");
        correo.appendChild(doc.createTextNode(String.valueOf(venta.getRepresentanteDeVentas().getCorreoElectronico())));
        datosRepresentante.appendChild(correo);
        
        return ventaElement;
    }
    
    private static Element crearGrupoVentas(Document doc, List <Venta> ventas) {
        Element ventitas = doc.createElement("Ventas");
        
        for (Venta venta : ventas) {
            Element ventaElement = crearElementoVenta(doc, venta);
            ventitas.appendChild(ventaElement);
        }
        
        return ventitas;
   
    }
    public static void main(String[] args) {
        // Crear clientes
    	
    	//String nombre, String apellido, String dni, String correoElectronico, String fechaNacimiento, double porcentajeDeComision
        Cliente cliente1 = new Cliente("Juan", "Pérez", "12345678A", "juan@example.com", "18-05-2005","27-02-2024");
        Cliente cliente2 = new Cliente("María","García", "87654321B", "maria@example.com", "18-06-2005","27-02-2023");
        Cliente cliente3 = new Cliente("Carlos","López", "11111111C", "carlos@example.com", "11-06-2005","27-02-2022");

        // Crear representantes de ventas
        RepresentanteDeVentas representante1 = new RepresentanteDeVentas("Pedro"," Martínez", "11122333X","pedro@gmail.com","18-05-2004", 10);
        RepresentanteDeVentas representante2 = new RepresentanteDeVentas("Ana", "Rodríguez", "44455666Y","ana@gmail.com", "01-05-2000", 12);
        RepresentanteDeVentas representante3 = new RepresentanteDeVentas("Luisa","Sánchez", "77788999Z","Luisa@gmail.com","01-05-2001", 15);

        // Crear ventas
        Venta venta1 = new Venta(LocalDate.of(2024, 2, 1), 100.0, "Producto A", 5, 0.21, cliente1, representante1);
        Venta venta2 = new Venta(LocalDate.of(2024, 2, 2), 200.0, "Producto B", 3, 0.18, cliente2, representante2);
        Venta venta3 = new Venta(LocalDate.of(2024, 2, 3), 150.0, "Producto C", 4, 0.20, cliente3, representante3);
        Venta venta4 = new Venta(LocalDate.of(2024, 2, 4), 120.0, "Producto D", 2, 0.15, cliente1, representante1);
        Venta venta5 = new Venta(LocalDate.of(2024, 2, 5), 180.0, "Producto E", 3, 0.18, cliente2, representante2);
        Venta venta6 = new Venta(LocalDate.of(2024, 2, 6), 90.0, "Producto F", 6, 0.25, cliente3, representante3);
        Venta venta7 = new Venta(LocalDate.of(2024, 2, 7), 250.0, "Producto G", 2, 0.22, cliente1, representante1);
        Venta venta8 = new Venta(LocalDate.of(2024, 2, 8), 300.0, "Producto H", 5, 0.20, cliente2, representante2);
        Venta venta9 = new Venta(LocalDate.of(2024, 2, 9), 180.0, "Producto I", 3, 0.15, cliente3, representante3);
        Venta venta10 = new Venta(LocalDate.of(2024, 2, 10), 150.0, "Producto J", 4, 0.18, cliente1, representante1);
        Venta venta11 = new Venta(LocalDate.of(2024, 2, 11), 200.0, "Producto K", 3, 0.20, cliente2, representante2);
        Venta venta12 = new Venta(LocalDate.of(2024, 2, 12), 120.0, "Producto L", 6, 0.25, cliente3, representante3);
        Venta venta13 = new Venta(LocalDate.of(2024, 2, 13), 170.0, "Producto M", 2, 0.22, cliente1, representante1);
        Venta venta14 = new Venta(LocalDate.of(2024, 2, 14), 190.0, "Producto N", 5, 0.20, cliente2, representante2);
        Venta venta15 = new Venta(LocalDate.of(2024, 2, 15), 220.0, "Producto O", 3, 0.18, cliente3, representante3);

        // Crear más ventas según sea necesario...

        // Crear negocio
        Venta[] ventas = { venta1, venta2, venta3, venta4, venta5, venta6, venta7, venta8, venta9, venta10, venta11, venta12, venta13, venta14, venta15 };
        Negocio negocio = new Negocio(ventas);
        System.out.println(negocio.getVenta(1).getArticulo());
        negocio.agregarVenta(venta1);
        negocio.agregarVenta(venta2);
        
       

        // Generar el archivo XML con la información del negocio
        negocio.sacarXML();
        
        System.out.println("Archivo XML generado correctamente.");
    }
}


