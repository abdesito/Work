/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ConexionDB;

import Contenido.globales;
import java.sql.*;
import javax.swing.JOptionPane;

public class ConexionDB {


    static {
        try {
            Class.forName(globales.driver);
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "ERROR EN EL DRIVER " + e);
        }
    }


    public Connection getConnection() throws SQLException {
       Connection con = null;
       try {
           con = DriverManager.getConnection(globales.url, globales.usuario, globales.password);
       } catch (SQLException e){
           JOptionPane.showMessageDialog(null, "Error de conexión: " + e.getMessage());
       }
       return con;
   }
}