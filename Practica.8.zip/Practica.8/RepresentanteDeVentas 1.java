//Prog_P6_Abdellah_Sahad.
package Practic8;


public class RepresentanteDeVentas extends Persona  {

	private double porcentajeDeComision;
	  // Constructor de la clase RepresentanteDeVentas con parámetros
    public RepresentanteDeVentas(String nombre, String apellido, String dni, String correoElectronico, String fechaNacimiento, double porcentajeDeComision) {
        super(nombre, apellido, dni, correoElectronico, fechaNacimiento);
        setPorcentajeDeComision(porcentajeDeComision);
    }
 // Método para obtener el porcentaje de comisión
    public double getPorcentajeDeComision() {
        return this.porcentajeDeComision;
    }
 // Método para asignar el porcentaje de comisión
    public void setPorcentajeDeComision(double porcentajeDeComision) {
        this.porcentajeDeComision = porcentajeDeComision;
    }
 // Método para obtener el nombre completo del representante de ventas
	public String getNombreCompletoRepresentanteDeVentas() {
		
		return getNombreCompleto();
	}
}

