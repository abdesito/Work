public class Eventos {
    public String eventoNombre = "";
    public int entradas = 0;

    public String[] posiblesNombres = {
            "Concierto 1", "Concierto 2", "Concierto 3",
            "Partido 1", "Partido 2", "Partido 3",
            "Taller 1", "Taller 2", "Taller 3"
    };

    public void crearEvento() {
        eventoNombre = posiblesNombres[(int) (Math.random() * posiblesNombres.length)];
        entradas = (int) (Math.random() * 50 + 100);
        System.out.println("Se ha creado el evento: " + eventoNombre + " con " + entradas + " entradas.");
    }
}
